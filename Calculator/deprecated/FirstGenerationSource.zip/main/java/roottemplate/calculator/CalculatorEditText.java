package roottemplate.calculator;

import android.content.Context;
import android.graphics.Rect;
import android.os.Build;
import android.support.annotation.NonNull;
import android.text.InputType;
import android.text.Layout;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.widget.EditText;

public class CalculatorEditText extends EditText {
    private String[] mMenuItemsStrings = null;
    private MenuHandler mHandler = new MenuHandler();
    MainActivity mMainActivity;
    boolean mIsResumed = true;

    public CalculatorEditText(Context context) {
        super(context);
        init();
    }

    public CalculatorEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public CalculatorEditText(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        if(Build.VERSION.SDK_INT >= 11)
            setCustomSelectionActionModeCallback(new NoTextSelectionMode());
        setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
    }

    public void appendToText(String str) {
        int select = getSelectionStart();
        setText(getEditableText().insert(select, str));
        setSelection(select + str.length());
    }
    public void setText(String str) {
        super.setText(str);
        setSelection(str.length());
    }
    public void clearText() {
        super.setText("");
    }
    public void delSymbol() {
        int select = getSelectionStart();
        if(select <= 0) return;

        super.setText(getEditableText().replace(select - 1, select, ""));
        setSelection(select - 1);
    }

    @Override
    protected void onCreateContextMenu(ContextMenu menu) {
        if(mMenuItemsStrings == null) {
            mMenuItemsStrings = new String[3];
            mMenuItemsStrings[0] = getContext().getResources().getString(R.string.menuItem_cut);
            mMenuItemsStrings[1] = getContext().getResources().getString(R.string.menuItem_copy);
            mMenuItemsStrings[2] = getContext().getResources().getString(R.string.menuItem_paste);
        }

        if(!getText().toString().isEmpty()) {
            menu.add(Menu.NONE, 0, 0, mMenuItemsStrings[0]).setOnMenuItemClickListener(mHandler);
            menu.add(Menu.NONE, 1, 1, mMenuItemsStrings[1]).setOnMenuItemClickListener(mHandler);
        }
        if(!ClipboardUtils.getPrimaryClip(getContext()).isEmpty())
            menu.add(Menu.NONE, 2, 2, mMenuItemsStrings[2]).setOnMenuItemClickListener(mHandler);
    }


    private boolean isFromMakeBlink() {
        StackTraceElement[] stack = Thread.currentThread().getStackTrace();
        for(StackTraceElement elem : stack) {
            if(     elem.getClassName().endsWith("$Blink") &&
                    elem.getClassName().startsWith("android.widget.") &&
                    elem.getMethodName().equals("run"))
                return true;
        }
        return false;
    }

    @Override
    public void invalidate() {
        if(isFromMakeBlink()) return;
        super.invalidate();
    }

    @Override
    public void invalidate(@NonNull Rect dirty) {
        if(isFromMakeBlink()) return;
        super.invalidate(dirty);
    }

    @Override
    public void invalidate(int l, int t, int r, int b) {
        if(isFromMakeBlink()) return;
        super.invalidate(l, t, r, b);
    }


    @Override
    public boolean onTouchEvent(@NonNull MotionEvent event) {
        if (event.getActionMasked() == MotionEvent.ACTION_UP) {
            // Hack to prevent keyboard and insertion handle from showing.
            cancelLongPress();

            if(mIsResumed) {
                // This is used to set cursor position for API > 10 (approximately)
                Layout layout = getLayout();
                float x = event.getX() + getScrollX();
                float y = event.getY() + getScrollY();
                int line = layout.getLineForVertical((int) y);
                int offset = layout.getOffsetForHorizontal(line, x);

                if (offset < 0) offset = 0;
                setSelection(offset);
            }
        }

        return super.onTouchEvent(event);
    }

    @Override
    public boolean performLongClick() {
        showContextMenu();
        return true;
    }



    private class MenuHandler implements MenuItem.OnMenuItemClickListener {
        @Override
        public boolean onMenuItemClick(MenuItem item) {
            switch(item.getItemId()) {
                case 0:
                    copy();
                    clearText();
                    return true;
                case 1:
                    copy();
                    return true;
                case 2:
                    mMainActivity.appendToExpr(ClipboardUtils.getPrimaryClip(getContext()));
                    return true;
            }
            return false;
        }

        public void copy() {
            ClipboardUtils.setPrimaryClip(getContext(), getText().toString());
        }
    }

    // API <= 10 will ignore that, so this error is not a big problem
    private class NoTextSelectionMode implements ActionMode.Callback {
        @Override
        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
            return false;
        }
        @Override
        public boolean onCreateActionMode(ActionMode mode, Menu menu) {
            mHandler.copy();
            // Prevents the selection action mode on double tap.
            return false;
        }
        @Override
        public void onDestroyActionMode(ActionMode mode) {}
        @Override
        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            return false;
        }
    }
}
