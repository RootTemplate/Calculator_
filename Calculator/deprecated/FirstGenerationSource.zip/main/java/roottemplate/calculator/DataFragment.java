package roottemplate.calculator;

import android.os.Bundle;
import android.support.v4.app.Fragment;

import roottemplate.calculator.evaluator.Evaluator;

import java.util.ArrayList;

public class DataFragment extends Fragment {
    ExprTextType mExprTextType = null;
    Evaluator mEvaluator = null;
    int mPadCurrentItem = -1;
    ArrayList<HistoryElement> mHistory = new ArrayList<>();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);
    }
}
