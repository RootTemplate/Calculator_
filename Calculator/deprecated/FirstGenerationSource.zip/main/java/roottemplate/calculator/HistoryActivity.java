package roottemplate.calculator;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;

public class HistoryActivity extends ListActivity {
    private ArrayList<HistoryElement> mHistory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent intent = getIntent();
        mHistory = intent.getParcelableArrayListExtra("data");

        if(!mHistory.isEmpty()) {
            setListAdapter(new ArrayAdapter<HistoryElement>(this,
                    android.R.layout.simple_list_item_1, mHistory) {

                @Override
                public View getView(int position, View convertView, ViewGroup parent) {
                    TextView view = (TextView) super.getView(position, convertView, parent);
                    String inner = view.getText().toString();
                    view.setText(Html.fromHtml(inner));
                    return view;
                }

                @Override
                public HistoryElement getItem(int position) {
                    return super.getItem(getCount() - 1 - position);
                }
            });
            registerForContextMenu(getListView());
        } else {
            setListAdapter(new ArrayAdapter<>(this, R.layout.system_textview,
                    Collections.singletonList(getResources().getString(R.string.nothingToShow))));
        }
    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);
        v.showContextMenu();
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);

        AdapterView.AdapterContextMenuInfo info;
        try {
            info = (AdapterView.AdapterContextMenuInfo) menuInfo;
        } catch (ClassCastException e) {
            MainActivity.log(e.getMessage());
            return;
        }
        ListAdapter adapter = getListAdapter();
        long id = adapter.getCount() - 1 - adapter.getItemId(info.position);
        HistoryElement elem = mHistory.get((int) id);

        menu.add(Menu.NONE, 0, Menu.NONE, R.string.menuItem_history_copyExpr);
        if(elem.equals != null) {
            menu.add(Menu.NONE, 1, Menu.NONE, elem.isError ?
                    R.string.menuItem_history_copyError : R.string.menuItem_history_copyEquals);
            menu.add(Menu.NONE, 2, Menu.NONE, R.string.menuItem_history_copyAll);
        }
        menu.add(Menu.NONE, 3, Menu.NONE, R.string.menuItem_history_enterExpr);
        if(elem.equals != null && !elem.isError)
            menu.add(Menu.NONE, 4, Menu.NONE, R.string.menuItem_history_enterEquals);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info;
        try {
            info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        } catch (ClassCastException e) {
            MainActivity.log(e.getMessage());
            return false;
        }
        ListAdapter adapter = getListAdapter();
        long id = adapter.getCount() - 1 - adapter.getItemId(info.position);
        HistoryElement elem = mHistory.get((int) id);

        Intent intent = null;
        switch (item.getItemId()) {
            case 0:
                ClipboardUtils.setPrimaryClip(this, elem.expr);
                return true;

            case 1:
                ClipboardUtils.setPrimaryClip(this, elem.equals);
                return true;

            case 2:
                ClipboardUtils.setPrimaryClip(this, elem.toStringNoFormat());
                return true;

            case 3:
                intent = new Intent();
                intent.putExtra("duplicate", elem.expr);
                break;

            case 4:
                intent = new Intent();
                intent.putExtra("duplicate", elem.equals);
                break;
        }

        if (intent != null) {
            setResult(RESULT_OK, intent);
            finish();
            return true;
        }

        return super.onContextItemSelected(item);
    }
}
