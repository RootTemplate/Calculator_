package roottemplate.calculator;

import android.content.res.Resources;

import roottemplate.calculator.evaluator.Evaluator;
import roottemplate.calculator.evaluator.EvaluatorException;

import java.util.HashMap;
import java.util.Map;

class EvaluatorBridge {
    public final HashMap<String, String> mSymbolsReplaceMap = new HashMap<>();
    public final String mBracketOpen;
    public final String mBracketClose;
    public final String mInfinity;

    public final DataFragment mData;

    public EvaluatorBridge(Resources res, DataFragment data) {
        mSymbolsReplaceMap.put(res.getString(R.string.symbol_minus), "-");
        mSymbolsReplaceMap.put(res.getString(R.string.symbol_multiply), "\\*");
        mSymbolsReplaceMap.put(res.getString(R.string.symbol_divide), "/");

        mBracketOpen = res.getString(R.string.symbol_bracketOpen);
        mBracketClose = res.getString(R.string.symbol_bracketClose);
        mInfinity = res.getString(R.string.symbol_infinity);

        mData = data;
        if(data.mEvaluator == null) {
            data.mEvaluator = new Evaluator();
        }
    }


    Evaluator getNamespace() {
        return mData.mEvaluator;
    }

    public roottemplate.calculator.evaluator.Number eval(String expr) throws EvaluatorException {
        return mData.mEvaluator.process(replaceSymbolsToEvaluator(expr));
    }
    public int clear() {
        return mData.mEvaluator.clear();
    }

    public String replaceSymbolsToEvaluator(String str) {
        for(String s : mSymbolsReplaceMap.keySet())
            if(str.contains(s))
                str = str.replaceAll(s, mSymbolsReplaceMap.get(s));
        return str;
    }
    public String replaceSymbolsFromEvaluator(String str) {
        for(Map.Entry e : mSymbolsReplaceMap.entrySet()) {
            String checking = (String) e.getValue();
            if(checking.startsWith("\\"))
                checking = checking.substring(1);
            if (str.contains(checking))
                str = str.replaceAll((String) e.getValue(), (String) e.getKey());
        }
        str = str.replaceAll("Infinity", mInfinity);
        return str;
    }

    public String closeUnclosedBrackets(String text, byte type) {
        if(type == 3) return text;

        int bracketsOpen = countRepeats(text, mBracketOpen);
        if(bracketsOpen == 0 || (type == 2 && bracketsOpen != 1)) return text;
        int close = bracketsOpen - countRepeats(text, mBracketClose);
        if(close == 0) return text;


        StringBuilder sb = new StringBuilder(text);
        for(int i = 0; i < close; i++)
            sb.append(mBracketClose);
        return sb.toString();
    }

    public int countRepeats(String in, String needle) {
        int i = -1;
        int count = 0;
        while((i = in.indexOf(needle, i + 1)) != -1)
            count++;
        return count;
    }
}
