package roottemplate.calculator;

import android.app.Activity;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

public class PadPagerAdapter extends PagerAdapter {
    //public static final int ITEM_GRAPHBUILDER = 0;
    public static final int ITEM_NAMES = 0;
    public static final int ITEM_MAIN = 1;
    public static final int ITEM_ADVANCED = 2;

    private final ViewPager mViewPager;
    private final List<View> mViewList;
    private final DataFragment mData;

    public PadPagerAdapter(Activity context, ViewPager viewPager, DataFragment data) {
        mViewList = new ArrayList<>(4);
        LayoutInflater inflater = LayoutInflater.from(context);
        //mViewList.add(inflater.inflate(R.layout.pad_graphbuilder, null));
        mViewList.add(inflater.inflate(R.layout.pad_names, null));
        mViewList.add(inflater.inflate(R.layout.pad_main, null));
        mViewList.add(inflater.inflate(R.layout.pad_advanced, null));

        mViewPager = viewPager;
        viewPager.setAdapter(this);

        mData = data;
        int setItemTo = data.mPadCurrentItem == -1 ? ITEM_MAIN : data.mPadCurrentItem;
        data.mPadCurrentItem = -1;
        setCurrentItem(setItemTo);
    }

    View getItemView(int index) {
        return mViewList.get(index);
    }
    public void setCurrentItem(int item) {
        if(mViewPager.getCurrentItem() == item) return;
        mViewPager.setCurrentItem(item);
        mData.mPadCurrentItem = item;
    }
    public int getCurrentItem() {
        return mViewPager.getCurrentItem();
    }

    @Override
    public int getCount() {
        return mViewList.size();
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        View v = mViewList.get(position);
        container.addView(v, 0);
        return v;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view.equals(object);
    }
}
