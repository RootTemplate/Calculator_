package roottemplate.calculator;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.preference.PreferenceManager;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.graphics.Paint;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import roottemplate.calculator.evaluator.EvaluatorException;
import roottemplate.calculator.evaluator.util.Util;

public class MainActivity extends AppCompatActivity {
    private static final boolean DEBUG = true;
    private static final byte REQUEST_CODE_HISTORY = 1;
    private static final byte REQUEST_CODE_SETTINGS = 2;

    /*static {
        System.loadLibrary("native");
    }*/

    public static void log(String text) {
        if(DEBUG)
            Log.d("Calculator", text);
    }

    private static String colorToString(int color) {
        return "#" + Integer.toHexString(color & 0x00ffffff);
    }



    private CalculatorEditText mExpr;
    private int mMaxDigits;
    EvaluatorBridge mEvaluator;
    private PadPagerAdapter mPadAdapter;
    private DataFragment mData;
    private SharedPreferences mSharedPrefs;


    public String getPrefString(String name, int defId) {
        return mSharedPrefs.getString(name, getResources().getString(defId));
    }
    public boolean getPrefBool(String name, int defId) {
        return mSharedPrefs.getBoolean(name, Boolean.parseBoolean(getResources().getString(defId)));
    }
    byte getPrefClosingBrackets() {
        return Byte.parseByte(getPrefString("pref_closingBrackets", R.string.pref_def_closingBrackets));
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mExpr = (CalculatorEditText) findViewById(R.id.activity_main_expr);
        mExpr.mMainActivity = this;
        mExpr.setSelection(0);
        mExpr.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_UP && mExpr.mIsResumed) {
                    setExprTextType(ExprTextType.INPUT);
                }
                return false;
            }
        });

        View del = findViewById(R.id.activity_main_del);
        del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mData.mExprTextType != ExprTextType.INPUT)
                    clear();
                else
                    del();
            }
        });
        del.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                clear();
                return true;
            }
        });

        FragmentManager fm = getSupportFragmentManager();
        mData = (DataFragment) fm.findFragmentByTag("data");
        if(mData == null) {
            mData = new DataFragment();
            fm.beginTransaction().add(mData, "data").commit();
            setExprTextType(ExprTextType.INPUT);
        } else {
            ExprTextType setTo = mData.mExprTextType;
            mData.mExprTextType = null;
            setExprTextType(setTo);
        }

        mPadAdapter = new PadPagerAdapter(this,
                (ViewPager) findViewById(R.id.activity_main_padViewer), mData);
        mEvaluator = new EvaluatorBridge(getResources(), mData);
        mSharedPrefs = PreferenceManager.getDefaultSharedPreferences(this);

        HistoryElement.EQUALS_COLOR = colorToString(getResources().getColor(R.color.equals));
        HistoryElement.ERROR_DETAIL_COLOR = colorToString(getResources().getColor(R.color.errorDetail));
        // This will be the same every time MainActivity launched, so this field can be static
        HistoryElement.ERROR_MESSAGE = getResources().getString(R.string.error);
    }

    @Override
    protected void onResume() {
        super.onResume();
        mData.mEvaluator.options.ANGLE_MEASURING_UNITS = Integer.parseInt(
                getPrefString("pref_amu", R.string.pref_def_amu));
        /*GraphbuilderView.SCALE_UNKNOWN_NUMBER =
                mSharedPrefs.getInt("pref_graphbuilder_scaleunknownnumber", (int) GraphbuilderView.SCALE_UNKNOWN_NUMBER * 10) /
                (float) 10;*/
        mExpr.mIsResumed = true;
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        mExpr.mIsResumed = hasFocus;

        if(hasFocus) {
            Paint paint = new Paint();
            paint.setTextSize(mExpr.getTextSize());
            mMaxDigits = Math.round((mExpr.getWidth() - 2) / paint.measureText("d"));
        }
    }

    /*
    * Possible tags: "digit", "function".
    */
    private View mViewLastClicked = null;
    private long mTimeLastClicked = -1;
    public void onClick(View view) {
        String add;
        switch(view.getId()) {
            case R.id.pad_equals:
                eval();
                return;
            case R.id.pad_abs:
                add = "abs";
                break;
            default:
                add = ((TextView) view).getText().toString();
                break;
        }

        long time = System.currentTimeMillis();
        boolean doubleClick = view == mViewLastClicked && (time - mTimeLastClicked) <= 400;
        mViewLastClicked = view;
        mTimeLastClicked = time;
        int currentPad = mPadAdapter.getCurrentItem();

        if(!(doubleClick && currentPad != PadPagerAdapter.ITEM_MAIN)) {
            if (view.getTag() != null) {
                if (mData.mExprTextType != ExprTextType.INPUT && view.getTag().equals("digit"))
                    mExpr.clearText();
                if (view.getTag().equals("function"))
                    add += mEvaluator.mBracketOpen;
            }

            appendToExpr(add);
        }

        if(mPadAdapter.getCurrentItem() == PadPagerAdapter.ITEM_ADVANCED || doubleClick)
            mPadAdapter.setCurrentItem(PadPagerAdapter.ITEM_MAIN);
            // In fact, this line should not be executed if view is a digit,
            // but this may happen and everything will be OK until all digits
            // are located in main pad.
    }

    private void setExprTextType(ExprTextType type) {
        if(type == mData.mExprTextType) return;

        if(type == ExprTextType.INPUT) {
            mExpr.setTextColor(getResources().getColor(R.color.editTextTextColor));
            mExpr.setCursorVisible(true);

            if(mData.mExprTextType == ExprTextType.RESULT_MESSAGE)
                mExpr.clearText();
        } else {
            mExpr.setTextColor(getResources().getColor(R.color.equals));
            mExpr.setCursorVisible(false);
        }
        mData.mExprTextType = type;
    }

    private void eval() {
        if(mData.mExprTextType != ExprTextType.INPUT) return; // already evaluated
        String text = getExpr();
        if(text.isEmpty()) return;

        text = mEvaluator.closeUnclosedBrackets(text, getPrefClosingBrackets());
        String result = "";
        String error = null;
        ExprTextType type;
        byte historyElemType = 0; // 0 - no, 1 - expr, 2 - expr and equals

        try {
            roottemplate.calculator.evaluator.Number n = mEvaluator.eval(text);

            if (n != null) {
                switch(getPrefString("pref_roundingType", R.string.pref_def_roundingType)) {
                    case "1":
                        double value = n.doubleValue();
                        for (int precision = mMaxDigits; precision >= 3; precision--) {
                            result = Util.doubleToString(value, precision);
                            if (result.length() <= mMaxDigits) {
                                break;
                            }
                        }
                        break;

                    case "2":
                        result = n.stringValue();
                        break;

                    case "3":
                        result = Double.toString(n.doubleValue());
                        break;
                }


                type = ExprTextType.RESULT_NUMBER;
                historyElemType = 2;
            } else {
                type = ExprTextType.RESULT_MESSAGE;
                result = mExpr.getText().toString();
                historyElemType = 1;
            }
        } catch (EvaluatorException e) {
            error = mEvaluator.replaceSymbolsFromEvaluator(e.getMessage());
            Toast.makeText(this, error, Toast.LENGTH_SHORT).show();
            result = getResources().getString(R.string.error);
            type = ExprTextType.RESULT_MESSAGE;
            historyElemType = (byte) (3 - Integer.parseInt(getPrefString("pref_history_errors",
                    R.string.pref_def_history_errors)));
        }

        result = mEvaluator.replaceSymbolsFromEvaluator(result);
        mExpr.setText(result);
        setExprTextType(type);
        if(historyElemType != 0 && getPrefBool("pref_history_enable", R.string.pref_def_history_enable)) {
            String equals = null;
            if(historyElemType == 2)
                if(error != null) equals = error;
                else equals = result;

            int length = mData.mHistory.size();
            HistoryElement elem = new HistoryElement(text, equals, error != null);
            if(length == 0 || !mData.mHistory.get(length - 1).toString().equals(elem.toString()))
                mData.mHistory.add(elem);
        }
    }

    String getExpr() {
        return mExpr.getText().toString().trim();
    }
    void appendToExpr(String text) {
        setExprTextType(ExprTextType.INPUT);
        mExpr.appendToText(text);
    }
    private void del() {
        setExprTextType(ExprTextType.INPUT);
        mExpr.delSymbol();
    }
    private void clear() {
        setExprTextType(ExprTextType.INPUT);
        mExpr.clearText();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        boolean result = super.onPrepareOptionsMenu(menu);
        if(!result) return false;

        MenuItem historyItem = menu.findItem(R.id.action_history);
        boolean prefsEnabledHistory = getPrefBool("pref_history_enable",
                R.string.pref_def_history_enable);
        boolean realEnabledHistory = historyItem.isVisible();
        if(prefsEnabledHistory != realEnabledHistory) {
            historyItem.setVisible(prefsEnabledHistory);
            menu.findItem(R.id.action_clear_history).setVisible(prefsEnabledHistory);
            if(Build.VERSION.SDK_INT >= 11)
                invalidateOptionsMenu();
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if(id == R.id.action_clear_namespace) {
            int cleared = mEvaluator.clear();
            Toast.makeText(this, getResources().getString(R.string.objects_deleted) + " " + cleared, Toast.LENGTH_SHORT).show();
            return true;
        } else if(id == R.id.action_clear_history) {
            mData.mHistory.clear();
            if(mData.mExprTextType != ExprTextType.INPUT) {
                setExprTextType(ExprTextType.INPUT);
                mExpr.clearText();
            }
            Toast.makeText(this, getResources().getString(R.string.history_cleared), Toast.LENGTH_SHORT).show();
            return true;
        } else if(id == R.id.action_history) {
            Intent historyIntent = new Intent(this, HistoryActivity.class);
            historyIntent.putParcelableArrayListExtra("data", mData.mHistory);
            startActivityForResult(historyIntent, REQUEST_CODE_HISTORY);
            return true;
        } else if (id == R.id.action_settings) {
            Intent settingsIntent = new Intent(this, SettingsActivity.class);
            startActivityForResult(settingsIntent, REQUEST_CODE_SETTINGS);
            return true;
        } else if(id == R.id.action_reference) {
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://roottemplate.pe.hu/Calculator"));
            startActivity(browserIntent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == REQUEST_CODE_HISTORY && resultCode == RESULT_OK) {
            if(data.hasExtra("duplicate")) {
                if(mData.mExprTextType != ExprTextType.INPUT)
                    clear();
                appendToExpr(data.getStringExtra("duplicate"));
            }
        } else if(requestCode == REQUEST_CODE_SETTINGS && resultCode == RESULT_OK) {
            if(data.hasExtra("history_enable") && !data.getBooleanExtra("history_enable", true))
                mData.mHistory.clear();
        }
    }
}
