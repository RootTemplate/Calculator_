package roottemplate.calculator;

import android.os.Parcel;
import android.os.Parcelable;

public class HistoryElement implements Parcelable {
    static String EQUALS_COLOR = null;
    static String ERROR_DETAIL_COLOR = null;
    static String ERROR_MESSAGE = null;

    public static final Parcelable.Creator<HistoryElement> CREATOR
            = new Parcelable.Creator<HistoryElement>() {
        public HistoryElement createFromParcel(Parcel in) {
            return new HistoryElement(in.readString(), in.readString(), in.readByte() == 1);
        }

        public HistoryElement[] newArray(int size) {
            return new HistoryElement[size];
        }
    };

    final String expr;
    final String equals;
    final boolean isError;

    HistoryElement(String expr) {
        this(expr, null);
    }
    HistoryElement(String expr, String equals) {
        this(expr, equals, false);
    }
    HistoryElement(String expr, String equals, boolean isError) {
        this.expr = expr;
        this.equals = equals;
        this.isError = isError;
    }

    public String toStringNoFormat() {
        if(!isError)
            return expr + (equals == null ? "" : " = " + equals);
        else
            return expr + " = " + ERROR_MESSAGE + (equals == null ? "" : " (" + equals + ")");
    }

    @Override
    public String toString() {
        String result = expr;
        if(isError)
            result = "<s>" + result + "</s>";
        if(equals != null || isError) {
            result += " =<font color=\"" + EQUALS_COLOR + "\">";
            if(isError)
                result += " " + ERROR_MESSAGE;
            if(equals != null)
                result += " " + (isError ? "</font><font color=\"" + ERROR_DETAIL_COLOR +
                        "\">(" + equals + ")" : equals);
            result += "</font>";
        }
        return result;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(expr);
        dest.writeString(equals);
        dest.writeByte((byte) (isError ? 1 : 0));
    }
}
