package roottemplate.calculator;

enum ExprTextType {
    INPUT, RESULT_NUMBER, RESULT_MESSAGE
}
