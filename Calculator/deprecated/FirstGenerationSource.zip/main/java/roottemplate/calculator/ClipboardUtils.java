package roottemplate.calculator;

import android.content.Context;
import android.text.ClipboardManager;

class ClipboardUtils {

    public static void setPrimaryClip(Context context, String clip) {
        ClipboardManager clipboard = (ClipboardManager) context.
                getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setText(clip);
    }

    public static String getPrimaryClip(Context context) {
        ClipboardManager clipboard = (ClipboardManager) context.
                getSystemService(Context.CLIPBOARD_SERVICE);
        CharSequence text = clipboard.getText();
        return (text == null) ? "" : text.toString();
    }
}
